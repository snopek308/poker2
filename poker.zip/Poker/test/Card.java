/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asnopek
 */
class Card {
    
    public int number;
    public String suit;
    
    public Card()
    {
        
    }
    
    public Card(int number, String suit){
        //constructor
    this.number = number;
    this.suit = suit;
}
    
    public boolean equals(Card c){
        if(this.number == c.number && this.suit.equals(c.suit))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    
    
}
